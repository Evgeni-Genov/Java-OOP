package viceCity;

import viceCity.core.ControllerImpl;
import viceCity.core.EngineImpl;
import viceCity.core.interfaces.Controller;
import viceCity.core.interfaces.Engine;
import viceCity.models.guns.Gun;
import viceCity.models.neighbourhood.GangNeighbourhood;
import viceCity.models.neighbourhood.Neighbourhood;
import viceCity.models.players.Player;
import viceCity.repositories.GunRepository;
import viceCity.repositories.PlayerRepository;
import viceCity.repositories.interfaces.Repository;

public class Main {
    public static void main(String[] args) {

        PlayerRepository<Player> playerRepository = new PlayerRepository<>();
        GunRepository<Gun> gunRepository = new GunRepository<>();
        Neighbourhood neighbourhood = new GangNeighbourhood();


        Controller controller = new ControllerImpl(gunRepository, playerRepository, neighbourhood); // TODO
        Engine engine = new EngineImpl(controller);
        engine.run();
    }
}

